/*
* first program in c
*/

#include <stdio.h>

int main(void)
{
    printf("hello, world\n");
}