<form action="settings.php" method="post">
    <fieldset>
        <div class="form-group">
            <input class="form-control" name="new_password" placeholder="New password" type="password"/>
        </div>
        <div class="form-group">
            <input class="form-control" name="confirmation" placeholder="Confirm new password" type="password"/>
        </div>
        <div class="form-group">
            <button class="btn btn-warning" type="submit">Change password</button>
        </div>
    </fieldset>
</form>
