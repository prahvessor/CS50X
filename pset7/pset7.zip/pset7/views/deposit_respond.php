<div class="alert alert-success">
    <p>New balance: $<?= number_format($cash, 2, '.', ',') ?></p>
</div>
