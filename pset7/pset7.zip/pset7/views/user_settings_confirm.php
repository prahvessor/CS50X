<div class="alert alert-success">
  <strong>Password updated</strong>
</div>