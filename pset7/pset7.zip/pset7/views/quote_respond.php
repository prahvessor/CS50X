
<div class="alert alert-info">
  <strong><?=$stock["symbol"]?></strong> &nbsp;<?=$stock["name"]?>&nbsp;<b><?=number_format($stock["price"], 2, '.', ',');?></b>
</div>
