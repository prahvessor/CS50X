<form action="deposit.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="money" placeholder="Extra money" type="text"/>
        </div>
        
        <div class="form-group">
            <button class="btn btn-primary" type="submit">
                <span aria-hidden="true" ></span>
                Add money
            </button>
        </div>
    </fieldset>
</form>

